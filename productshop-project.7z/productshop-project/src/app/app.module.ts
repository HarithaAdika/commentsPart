import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {ProductService} from './product.service';
import {Product} from './products';
import {HttpClientModule} from '@angular/common/http';
import {FormsModule} from '@angular/forms'
import { AppComponent } from './app.component';
import {NgxPaginationModule} from 'ngx-pagination';
import {ProductsRouteModule} from './products-route.module';
import { AddProductComponent } from './add-product/add-product.component';
import { ProductComponent } from './product/product.component';
import { EditProductComponent } from './edit-product/edit-product.component';


@NgModule({
  declarations: [
    AppComponent,
    AddProductComponent,
    ProductComponent,
    EditProductComponent,
    
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    NgxPaginationModule,
    ProductsRouteModule
  ],
  providers: [ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }
