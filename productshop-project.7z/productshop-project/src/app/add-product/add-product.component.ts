import { Component, OnInit } from '@angular/core';
import {ProductService} from '../product.service';
import {FormsModule} from '@angular/forms'
import {Router} from '@angular/router';
@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {
pId:number;
pName:string;
pDes:string;
pPrice:number;
strArr:string;
products:any;
  constructor(private productservice:ProductService,private router:Router) { }
   addProducts(){
     console.log(this.pName,this.pDes,this.pId,this.pPrice);
     this.productservice.postProducts(this.pName,this.pDes,this.pId,this.pPrice).subscribe((data:any)=>{
      this.cancelData();
      this.router.navigate(['\submit']);
       
     });
   }
   cancelData(){
     this.pId=null,
     this.pPrice=null,
     this.pName='',
     this.pDes=''
      this.router.navigate(['\cancel']);
   }
  ngOnInit() {
  }

}
