import { Injectable } from '@angular/core';
import { Product } from './products';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ProductService {
  productPrice: any;
  productDes: any;
  productName: any;
    product= new Set();
  private getURL: string = "http://localhost:3200/products/get";
   private delURL: string = "http://localhost:3200/products/deleteall";
  private postURL: string = "http://localhost:3200/products/post";
  private deleteURL: string = "http://localhost:3200/products/delete/";
  private updateURL: string = "http://localhost:3200/products/update/";
  constructor(private http: HttpClient) { 
    
  }
  /*--- for getting the products list----*/
  getProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(this.getURL);

  }
  delProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(this.delURL);

  }
  /*---- Adding the product ------------------*/
  postProducts(ename: string, edes: string, eid: number, eprice: number, ): Observable<any> {
   
    return this.http.post(this.postURL, {
      id: eid,
      Name: ename,
      Description: edes,
      Price: eprice
    })
  }
  /*--- for updating the product -----------*/
  updateProducts(data, id): Observable<Product[]> {
    return this.http.put<Product[]>(this.updateURL + id, data);
  }

/*--- For deleteing the product---------------*/
  deleteProducts(id:number): Observable<Product[]> {
    console.log(id);
    return this.http.delete<Product[]>(this.deleteURL + id);
  }
  /*----- Servicing the data -----------*/
  productId:number;
  sendData(pid,pname,pdes,pprice){
    this.product.add({"id":pid,"name":pname,"des":pdes,"price":pprice});
   
    console.log(this.product);

  }
  recieveData(){
    return this.product;
  }
  
}
