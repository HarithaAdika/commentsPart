import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule,Routes} from '@angular/router';
import {AppComponent} from './app.component';
import {ProductComponent} from './product/product.component'
import {AddProductComponent} from './add-product/add-product.component';
import {EditProductComponent} from './edit-product/edit-product.component'
const routes: Routes = [
  { path: '', redirectTo: '/product', pathMatch: 'full' },
  { path: 'product', component: ProductComponent },
  {path:'addproduct',component:AddProductComponent},
  {path:'submit',component:ProductComponent},
  {path:'cancel',component:ProductComponent},
  {path:'Edit',component:EditProductComponent}
];
@NgModule({
  imports: [
    CommonModule,RouterModule.forRoot(routes)
  ],
  exports:[RouterModule],
  declarations: []
})
export class ProductsRouteModule { }
