import { ProductsRouteModule } from './products-route.module';

describe('ProductsRouteModule', () => {
  let productsRouteModule: ProductsRouteModule;

  beforeEach(() => {
    productsRouteModule = new ProductsRouteModule();
  });

  it('should create an instance', () => {
    expect(productsRouteModule).toBeTruthy();
  });
});
