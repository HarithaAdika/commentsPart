import { Component, OnInit } from '@angular/core';
import {ProductService} from '../product.service';
import {Router} from '@angular/router'
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
products=[];
  page:number=1;
  pId:number;

pPrice:number;
pName:string;
pDes:string;
proID:number;
proName:string;
proDes:string;
proPrice:number;
strObj:string;
  constructor(private productservice:ProductService,private router:Router) { }

  ngOnInit(){
    this.productservice.getProducts().
    subscribe(data=>(this.products=data));
    
  }
  
  addProduct(){
     this.router.navigate(['\addproduct']);
  }
   deleteProduct(id) {
    let confirmation = confirm("Are you sure you want to delete ?");
    if (confirmation) {
      this.productservice.deleteProducts(id)
        .subscribe(data => (this.products = data));
    }
  }
  
 editData(prodid: number,prodname:string,proddes:string,prodprice:number) {
    this.productservice.sendData(prodid,prodname,proddes,prodprice);
    this.productservice.getProducts().
    subscribe(data=>(this.products=data));
   this.router.navigate(['\Edit']);
 
  }
  deleteAll(){
      let check = confirm("Are you sure you want to delete ?");
      if (check) {
    this.productservice.delProducts().
    subscribe(data=>(this.products=data));
      }

  }

}
