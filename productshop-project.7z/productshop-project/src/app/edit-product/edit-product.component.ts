import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {ProductService} from '../product.service';
@Component({
  selector: 'app-edit-product',
  templateUrl: './edit-product.component.html',
  styleUrls: ['./edit-product.component.css']
})
export class EditProductComponent implements OnInit {
  
  pId: number;
products=[];
pPrice:number;
pName:string;
pDes:string;
proID:number;
proName:string;
proDes:string;
proPrice:number;
product:any;
proid:number;
strObj:string;
  constructor(private router:Router,private productservice:ProductService) { 
    this.product = this.productservice.recieveData();
  this.product.forEach(data => {
  this.proID=data.id;
  this.pName=data.name;
  this.pDes=data.des;
  this.pPrice=data.price;
  
});
  }

  ngOnInit() {
 
  }
  cancelData(){
     this.pId=null,
     this.pPrice=null,
     this.pName='',
     this.pDes=''
      this.router.navigate(['\cancel']);
   }
  
  updateProduct() {
    this.strObj ='{"id":' +this.proID +',"Name":"' +this.pName +'","Description":"' +
      this.pDes +'","Price":' +this.pPrice +"}";
    this.productservice
      .updateProducts(JSON.parse(this.strObj), this.proID)
      .subscribe(data => (this.products = data));
   
      
      this.router.navigate(['\product']);
     
    
  }
}
