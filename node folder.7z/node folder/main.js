
var Prod=require('./lib/add');
console.log("Welcome to Node Js");
/*
add.addData();
add.getData();
*/
//add.Products(2,'lap',40000);
//add.Products(1,'phone',4000);
var proOne=new Prod.products(2,'laptop',80000);
var proTwo=new Prod.products(3,'mobile',8000);
var proThree=new Prod.products(21,'TV',20000);
Prod.setData(proOne);
Prod.setData(proTwo);
Prod.setData(proThree);
Prod.display();
Prod.sortProd();
/*------Creating the buffer------------- */
var buff=new Buffer(20);
console.log(buff);
buff.write("Capgemini");
console.log(buff);
console.log(buff.toJSON());
console.log(buff.toString());
var buff1=new Buffer([1,2,3]);
console.log(buff1);
buff1.write("Cap");
console.log(buff1);


/*-------Creating an Event -------------------*/

var event=require('events');//Core module of node

var myEvent=new event.EventEmitter();
myEvent.on('callMe',function(temp,temp1)
    {
        console.log("Event has occured",temp,temp1);
         setTimeout(function()
        {
            console.log("......After Set Time out of 8 sec...........");

        },800);
        
    });
myEvent.on('clickMe',function(temp)
    {
       
        console.log("click event has occured",temp);
    });

myEvent.emit('callMe',".....Welcome to Capgemini!!!!!!!!!!!!","Its good to see you");
myEvent.emit('clickMe',".............Nice meeting you");