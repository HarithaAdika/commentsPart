var express = require('express');
var http = require('http');
var cors = require('cors');
var parser=require('body-parser');
var fs=require('fs');
var exp = express()
var prodData = fs.readFileSync('./products.json')
prodData = JSON.parse(prodData);
var delData=[];
exp.route('/products/get',cors()).get((req,res)=>{
    res.send(prodData);
});
exp.route('/products/deleteall',cors()).get((req,res)=>{
    console.log("delete invoked");
    fs.writeFileSync('products.json',JSON.stringify(delData));
    res.send(delData);
});
exp.use(parser.json());
exp.route('/products/post',cors()).post((req,res)=>{
    console.log(req.body);
    prodData.push(req.body);
    res.send(prodData);
    fs.writeFileSync('products.json',JSON.stringify(prodData));
})
exp.route('/products/delete/:id',cors()).delete((req,res)=>{
     var id = req.params.id;
    for (var i = 0; i < prodData.length; i++) {
        if (prodData[i].id == id) {
            prodData.splice(i, 1);
            console.log(prodData);
            res.send(prodData);
        }
    }
    fs.writeFileSync('products.json', JSON.stringify(prodData));

})
exp.route('/products/update/:id',cors()).put((req,res)=>{
    console.log("hello");
    var id = req.params.id;
    for (var pro of prodData) {
        if (pro.id == id) {
            pro.id = req.body.id;
            pro.Name = req.body.Name;
            pro.Description = req.body.Description;
            pro.Price = req.body.Price;
            res.send(prodData);
            console.log(prodData);
        }
    }
    fs.writeFileSync('products.json', JSON.stringify(prodData));
})



exp.listen(3200,()=>{
    console.log("Listening...............");
});