var http=require('http');
var express=require('express');
var url=require('url');
//var qs=require('querystring')
/*http.createServer(function(req,res){
    res.writeHead(200,{'Content-Type':'text/html'});
    res.end('Hello World!');
   

    //res.end();
}).listen(3000);*/
var exp=express();
var x=exp.get('/get',function(req,res){
res.writeHead(200,{'Content-Type':'text/html'});
res.write('hello'+req.query.id*3);
res.end();
})

http.createServer(x).listen(3001);

var y=exp.post('/submit',function(req,res){
res.writeHead(200,{'Content-Type':'text/html'});
res.write('hello');
res.end();
})
http.createServer(y).listen(3003);
var y=(req,res)=>{
    res.writeHead(200,{'Content-Type':'text/html'});
    res.write("<h2>hello world function</h2>");
    //res.write(req.url);
    var value=url.parse(req.url,true).query;
    var textvalue=value.year+""+value.month
    res.end(textvalue);
}
http.createServer(y).listen(3002);
var fs=require('fs');
var form=(req,res)=>{
    fs.readFile('lab7_prob2_forms.html',function(key,data){
    res.writeHead(200,{'Content-Type':'text/html'});
    res.write(data);
res.end();});
}
http.createServer(form).listen(8080);