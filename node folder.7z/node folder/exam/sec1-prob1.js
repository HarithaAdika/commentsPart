var http = require('http');
var express = require('express');
var cors = require('cors');
var parser=require('body-parser');
var fs=require('fs');
var app = express()
var mobileData = fs.readFileSync('./mobiles.json');
mobileData = JSON.parse(mobileData);

/*------------Fetching the mobile data from the JSON file and displaying all the data in the console -----------------------*/
app.route('/rest/api/get',cors()).get((req,res)=>{
    console.log("----Displaying All the mobiles----------- ");
     let mobData = fs.readFileSync('mobiles.json');
    let mobile = JSON.parse(mobData);
    console.log(mobile);
    res.send(mobile);
});

/*-------------Displaying the mobiles in the given range using the GET method------------------*/
app.route('/rest/api/search/:minprice/:maxprice').get((req,res)=>{
   res.send("mobiles from"+req.params['minprice']+""+req.params['maxprice']);
    mobileData.map(obj=>{
       if(obj.mobPrice >= eval(req.params['minprice'])&&
       (obj.mobPrice <= eval(req.params['maxprice']))){
            console.log(obj);
        
       }
    
    });    
});


/*-----------Updating the mobile Name baesd on the mobile id using the GET method -------------*/
app.route('/rest/api/update/:mobid').get((req,res)=>{

    mobileData.map(obj=>{
   id=eval(req.params['mobid']);
       if(obj.mobId ===id){
           obj.mobName='Samsung Galaxy';
           fs.writeFileSync('mobiles.json',JSON.stringify(mobileData));
           res.send(obj);
           console.log(obj);
       }
    })
})

app.use(parser.json());
/*---------Adding a new mobile data using the POST method----------------*/
app.route('/rest/api/post',cors()).post((req,res)=>{
    console.log("-------------Post Method invoked to add the mobile-----------");
   console.log(req.body); //Displays the data in the console
    mobileData.push(req.body);
    //Writes the new mobile data to mobiles.json file
fs.writeFileSync('./mobiles.json', JSON.stringify(mobileData));  
});

app.listen(8200); //The server listens on 8200 port