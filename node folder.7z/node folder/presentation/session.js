var express = require('express');
var session = require('client-sessions');
var bodyParser = require('body-parser');
var exp = express();


exp.set("view engine", "jade")

//instructing server to generate unique id

exp.use(session({
    cookieName: 'uniqid',
    secret: 'anyvalue',
    duration: 30 * 60 * 1000, //session time period
}));

exp.get('/createsession/:name', function (req, res) {
    var name = req.params['name'];
    console.log(req.params['name']);
    req.uniqid.name = name;
    if (name == 'abc') {
        //req.uniqid.name = name;
        //console.log("req/t" + req.uniqid.name);
        res.render('sample', { name });
    }
    else {
        res.render('index',{name:req.uniqid.name});
    }
});

exp.get('/extendsession',function(req,res){
    res.render('hello',{name:req.uniqid.name});
})

exp.get('/logout',function(req,res){
    //delete uniqid.name;
    req.uniqid.reset();
    //res.render('logout');
})

exp.listen(3000,()=>{
    console.log("Running.........");
})