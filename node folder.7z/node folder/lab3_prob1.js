var express = require('express');
var http = require('http');
var cors = require('cors');
var parser=require('body-parser');
var fs=require('fs');
var MongoClient = require('mongodb').MongoClient
var url = "mongodb://localhost:27017/";
var exp = express()

var jsondata = fs.readFileSync('./employees.json')

jsondata = JSON.parse(jsondata);

exp.get("/rest/api/load",cors(),(req,res)=>{
    console.log('Load Invoked');
    res.send({msg:'Loads the Json file'});
    
});
exp.route('/rest/api/get',cors()).get((req,res)=>{
    console.log("Get Invoked");
     let data = fs.readFileSync('employees.json');
    let employee = JSON.parse(data);
    console.log(employee);
    res.send(employee);
});
exp.route('/rest/api/get/:state').get((req,res)=>{
    res.send("Employees from state"+req.params['state']);
    jsondata.map(obj=>{
       if( obj.empAddress.state === req.params['state'] ){
           //obj.empAddress.stae='Hijiwade';
           //fs.writeFileSync(jsondata)
           console.log(obj);
       }
    })
})
exp.route('/rest/api/update/:id').get((req,res)=>{
   // res.send("Employees from id"+typeof(req.params['id']));
    jsondata.map(obj=>{
    //console.log(obj.empId +" " + req.params['id']);
       if(obj.empId === eval(req.params['id'])){
           obj.empAddress.city='New York';
           fs.writeFileSync('employees.json',JSON.stringify(jsondata));
           res.send(obj);
       }
    })
})
exp.use(parser.json());
exp.route('/rest/api/post',cors()).post((req,res)=>{
    console.log("Post Invoked");
    let data={
        "empId":1101,
        "empName":'Revanth',
        "empSalary":50000,
        "empAddress":{"city":'Bangalore',"state":'Karnataka'}

    }
    jsondata.push(data);
    
    //let emp = JSON.stringify(data);  
fs.writeFileSync('./employees.json', JSON.stringify(jsondata));  
});


exp.listen(3000);