import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NodeExampleComponent } from './node-example.component';

describe('NodeExampleComponent', () => {
  let component: NodeExampleComponent;
  let fixture: ComponentFixture<NodeExampleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NodeExampleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NodeExampleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
