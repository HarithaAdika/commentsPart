import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CallerService } from './caller.service';
import { AppComponent } from './app.component';
import {FormsModule} from '@angular/forms';
import { NodeExampleComponent } from './node-example/node-example.component';
import {HttpClientModule} from '@angular/common/http'
@NgModule({
  declarations: [
    AppComponent,
    NodeExampleComponent
  ],
  imports: [
    BrowserModule,FormsModule,
    HttpClientModule
  ],
  providers: [CallerService

  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
