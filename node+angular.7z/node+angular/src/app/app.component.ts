import { Component } from '@angular/core';
import { CallerService } from './caller.service';
 
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  delData: any;
  title = 'app';
  uname:string;
  age:number;
  get:any;
   post:any;
   getdata:any;
  constructor(private caller:CallerService) {
  
   }
   invokePost(){
     console.log(this.uname,this.age);
     this.caller.postData(this.uname,this.age).subscribe((data:any)=>{

     });
   }
   invokeGet(){
    this.caller.getData().subscribe(data=>{this.getdata=data});
    console.log(this.getdata);
   }
   invokeDelete(){
     this.caller.deleteData(this.delData).subscribe(data=>{
       
     });
   }
   invokeUpdate(){
     this.caller.updateData().subscribe(data=>{});
   }
   ngOnInit()
   {
        
          this.invokeGet();

   }

}
