import { Component,OnInit} from '@angular/core';
import {CommentService} from './comment.service';
import{FormsModule} from '@angular/forms';
import { AppRoutingModule } from './/app-routing.module';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'app';
name:string;
content:string;
  constructor(private myservie:CommentService){}
  data=[];
  
 strObj:string;
 ngOnInit()
 {
  
   
 }
  getCommentData(){
  
       return this.myservie.getComment().subscribe((d)=>{this.data=d});

  }

   
  postCommentData() {
    this.strObj = '{"name":"' + this.name + '","content":"' +
      this.content + '"}';
    console.log(this.strObj);
    return this.myservie.postComment(JSON.parse(this.strObj)).subscribe(d => {this.data = d});
   
  }
 

}
