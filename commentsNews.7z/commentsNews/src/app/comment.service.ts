import { Injectable } from '@angular/core';
import {IPost} from './comment';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from "rxjs";
import { delay } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class CommentService {

  constructor(private http:HttpClient) { }
 getComment(): Observable<IPost[]> {
    return this.http.get<IPost[]>('http://localhost:8080/getComments/dip95/7');
  }
  postComment(data):Observable<IPost[]>{
    var result =  this.http.put<IPost[]>('http://localhost:8080/updateComments/dip95/7',data);
    console.log(result);
    return result;
  }
}
