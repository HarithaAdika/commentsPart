export interface Product{
    id: number,
    Name: string,
    Description: string,
    Price: number
}